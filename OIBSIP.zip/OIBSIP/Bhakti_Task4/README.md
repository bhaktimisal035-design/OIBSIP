# Bhakti_Task4 — Email Spam Detection with Machine Learning

**Oasis Infobyte Internship (OIBSIP) — Task 4**

An NLP binary classifier that distinguishes spam messages from legitimate (ham) messages, built with TF-IDF features and classic ML classifiers.

## Objective
Build a Natural Language Processing (NLP) binary classifier that distinguishes spam emails/SMS from legitimate (ham) messages.

## Tech Stack
- Python
- pandas
- scikit-learn (TF-IDF, Multinomial Naive Bayes, Logistic Regression)
- NLTK
- WordCloud
- Jupyter Notebook

## Project Structure
```
Bhakti_Task4/
├── data/
│   └── spam.csv              # place the downloaded dataset here (not tracked in git)
├── notebooks/
│   └── Bhakti_Task4.ipynb
├── requirements.txt
├── .gitignore
└── README.md
```

## Dataset
This project uses the **SMS Spam Collection Dataset**, a classic labeled dataset of ~5,500 SMS messages tagged as `ham` or `spam`.

Download it from either:
- [Kaggle - SMS Spam Collection Dataset](https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset)
- [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/228/sms+spam+collection)

Place the downloaded `spam.csv` file inside the `data/` folder before running the notebook.

## Setup
```bash
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage
```bash
jupyter notebook notebooks/Bhakti_Task4.ipynb
```

Run the cells top to bottom. The notebook will:
1. Load and clean the dataset
2. Check class distribution (spam vs. ham)
3. Preprocess text (lowercasing, punctuation/stopword removal, lemmatization)
4. Extract TF-IDF features
5. Train Multinomial Naive Bayes and Logistic Regression classifiers
6. Evaluate with accuracy, precision, recall, F1-score, and confusion matrices
7. Discuss why recall matters for spam detection
8. Generate WordCloud visualisations for spam vs. ham vocabulary

## Results

> **Note:** The table below is from a run against **synthetic placeholder data** (see `data/README.md`) generated to verify the pipeline runs end to end — scores are unrealistically high because the synthetic ham/spam templates are very easy to separate. Swap in the real SMS Spam Collection dataset and re-run for genuine results before final submission.

| Model | Accuracy | Precision | Recall | F1-score |
|---|---|---|---|---|
| Multinomial Naive Bayes | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| Logistic Regression | 0.9940 | 1.0000 | 0.9524 | 0.9756 |

## License
This project is for educational purposes as part of an internship task.
