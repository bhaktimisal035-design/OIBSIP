A **synthetic placeholder** `spam.csv` is already included here so the notebook runs out of the box. It mimics the real dataset's format (`v1`=label, `v2`=text) but is templated text, not real SMS messages — good for testing the pipeline, not for genuine results.

For your actual submission, replace it with the real **SMS Spam Collection Dataset**:
- https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset
- https://archive.ics.uci.edu/dataset/228/sms+spam+collection

This file is intentionally excluded from git via `.gitignore` — do not commit the raw dataset either way.
