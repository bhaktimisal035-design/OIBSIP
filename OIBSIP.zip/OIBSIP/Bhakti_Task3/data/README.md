A **synthetic placeholder** `car_data.csv` is already included here (300+ rows) so the notebook runs out of the box. Prices follow a depreciation-based formula similar to real used-car pricing, but the listings themselves are generated, not real.

For your actual submission, replace it with the real **"Vehicle dataset from cardekho"** — search "car price prediction dataset" on Kaggle.
