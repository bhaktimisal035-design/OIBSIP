# Bhakti_Task3 — Car Price Prediction with Machine Learning

**Oasis Infobyte Internship (OIBSIP) — Task 3**

A regression project that predicts the selling price of a used car based on features such as brand, age, mileage, fuel type, and transmission.

## Objective
Build a regression model that predicts the selling price of a used car based on features such as brand, age, mileage, fuel type, and transmission.

## Tech Stack
- Python
- pandas
- scikit-learn (Linear Regression, Random Forest Regressor, Gradient Boosting Regressor)
- matplotlib
- seaborn
- Jupyter Notebook

## Project Structure
```
Bhakti_Task3/
├── data/
│   └── car_data.csv          # synthetic placeholder included — replace with the real dataset
├── notebooks/
│   └── Bhakti_Task3.ipynb
├── requirements.txt
└── README.md
```

## Dataset
This project targets the **"Vehicle dataset from cardekho"**, a widely used, publicly available used-car listings dataset.

Download it by searching "car price prediction dataset" on [Kaggle](https://www.kaggle.com). Place the CSV in the `data/` folder as `car_data.csv` (or update `DATA_PATH` in the notebook), with columns similar to:

`Car_Name, Year, Selling_Price, Present_Price, Kms_Driven, Fuel_Type, Seller_Type, Transmission, Owner`

## Setup
```bash
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage
```bash
jupyter notebook notebooks/Bhakti_Task3.ipynb
```

Run the cells top to bottom. The notebook will:
1. Load and clean the data (nulls, duplicates, inconsistent categorical casing)
2. Engineer features: car age (from year) and brand (from car name)
3. Run EDA: price distribution, price vs. fuel type, price vs. car age
4. One-hot encode categorical variables
5. Show a feature correlation heatmap
6. Split into train/test sets
7. Train Linear Regression, Random Forest Regressor, and Gradient Boosting Regressor
8. Evaluate with MAE, RMSE, and R² score
9. Plot a feature importance chart for the best-performing model

## Results

> **Note:** The table below is from a run against a **synthetic placeholder dataset** (see `data/README.md`), generated with a depreciation-based price formula similar to real used-car pricing so the pipeline could be verified end to end. Swap in the real cardekho dataset and re-run for genuine results before final submission.

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression | 1.1339 | 1.6403 | 0.8275 |
| Random Forest Regressor | 0.7987 | 1.1714 | 0.9120 |
| Gradient Boosting Regressor | 0.6188 | 0.9197 | 0.9458 |

Best model: **Gradient Boosting Regressor**. Top drivers of predicted price (from the synthetic run): **Present Price** (original brand-new price) had the largest importance, followed by **Car Age** and **Kms Driven** — matching the intuition that a car's original value and how much it has depreciated dominate its resale price, with brand/fuel/transmission playing a smaller role.

## License
This project is for educational purposes as part of an internship task.
