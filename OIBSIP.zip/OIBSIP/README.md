# OIBSIP

**Oasis Infobyte Summer Internship Program — Submissions by Bhakti**

- **Commencement Date:** 5 September 2026
- **Submission Deadline:** 15 October 2026

This repository contains all completed internship tasks, each in its own folder following the `YourName_TaskNumber` naming convention required by the internship guidelines.

## Tasks

| Task | Folder | Description |
|---|---|---|
| Task 3 | [`Bhakti_Task3`](./Bhakti_Task3) | Car Price Prediction with Machine Learning — Linear Regression, Random Forest, and Gradient Boosting on used-car listings |
| Task 4 | [`Bhakti_Task4`](./Bhakti_Task4) | Email Spam Detection with Machine Learning — TF-IDF + Naive Bayes / Logistic Regression NLP classifier |
| Task 5 | [`Bhakti_Task5`](./Bhakti_Task5) | Sales Prediction Using Python — Linear Regression + Random Forest regression on advertising spend data |

Each task folder is self-contained with its own `notebooks/`, `data/`, `README.md`, `requirements.txt`, and `.gitignore`. See the README inside each folder for setup and dataset download instructions.

## Guidelines followed
1. Professional presence maintained on LinkedIn, with milestones shared.
2. Original work — no plagiarism.
3. Each project includes a documented, well-commented Jupyter Notebook.
4. This repository is named **OIBSIP** as required.

## Submission
For each task, the official submission form is filled out with:
- This GitHub repository link (pointing to the relevant `YourName_TaskNumber` folder)
- A live demo link, where applicable
- Confirmation that the project is documented with a `README.md`

## Contact
For internship-related queries, see the Telegram group: https://t.me/oasisinfobyte
