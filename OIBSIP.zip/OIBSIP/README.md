# OIBSIP — Data Science Internship

**Intern:** Bhakti
**Program:** Oasis Infobyte Summer Internship Program (OIBSIP)
**Track:** Data Science

## 📅 Internship Schedule
| | |
|---|---|
| Commencement Date | 5 September 2026 |
| Submission Deadline | 15 October 2026 |

---

## Task 1 — Iris Flower Classification

**File:** `Bhakti_Task1.ipynb`

Trains a machine learning classification model to identify the species of an iris flower (*Setosa*, *Versicolor*, or *Virginica*) from its physical measurements.

### What the notebook covers
1. Loads the Iris dataset directly from `sklearn.datasets` — no external download needed.
2. Exploratory Data Analysis: shape, dtypes, missing-value check, class balance, descriptive statistics.
3. Visualisations: pairplot, per-species box plots, correlation heatmap.
4. Feature selection discussion — identifies the most discriminative measurements.
5. 80/20 train/test split, stratified by species.
6. Trains four classifiers: Logistic Regression, K-Nearest Neighbours, Decision Tree, Random Forest.
7. Evaluates every model with accuracy, confusion matrix, and a full precision/recall/F1 classification report.
8. Selects and justifies the best-performing model.

### Tech stack
Python, pandas, numpy, matplotlib, seaborn, scikit-learn, Jupyter Notebook

### Run it
```bash
pip install -r requirements.txt
jupyter notebook Bhakti_Task1.ipynb
```

No dataset download is required — the notebook loads the Iris data directly from scikit-learn.

### Result
Four classifiers are trained and compared on a held-out 20% test set (90–97%+ accuracy depending on random seed). Petal length and petal width are the most discriminative features. Full metrics, confusion matrices, and the final model justification are in the notebook.

---

## 📁 Repository Structure
```
OIBSIP/
├── Bhakti_Task1.ipynb     # Task 1 — Iris Flower Classification
├── requirements.txt       # Python dependencies
├── README.md              # This file
└── .gitignore
```
As further tasks are completed, they will be added here following the same `Bhakti_TaskNumber` naming convention.

## ✅ Guideline Compliance
- [x] GitHub repository named **OIBSIP**
- [x] File naming format: **Bhakti_TaskNumber**
- [x] Project documented with a README
- [ ] GitHub repository link + live demo (if applicable) included in the official submission form
- [ ] LinkedIn post sharing this milestone

## 📚 References
- [scikit-learn User Guide](https://scikit-learn.org/stable/user_guide.html)
- [Iris dataset documentation](https://scikit-learn.org/stable/datasets/toy_dataset.html#iris-plants-dataset)
