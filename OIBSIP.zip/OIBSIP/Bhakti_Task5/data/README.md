A **synthetic placeholder** `Advertising.csv` is already included here so the notebook runs out of the box. It has the same columns (TV, Radio, Newspaper, Sales) and a similar underlying relationship to the real dataset, but the rows are generated, not real.

For your actual submission, replace it with the real dataset — search "advertising sales prediction dataset" on Kaggle.

This file is intentionally excluded from git via `.gitignore` — do not commit the raw dataset either way.
