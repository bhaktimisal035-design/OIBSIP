# Bhakti_Task5 — Sales Prediction Using Python

**Oasis Infobyte Internship (OIBSIP) — Task 5**

A regression project that predicts product sales based on advertising spend across TV, Radio, and Newspaper channels.

## Objective
Build a regression model that predicts product sales based on advertising spend across different media channels (TV, Radio, Newspaper).

## Tech Stack
- Python
- pandas
- scikit-learn (Linear Regression, Random Forest Regressor)
- matplotlib
- seaborn
- Jupyter Notebook

## Project Structure
```
Bhakti_Task5/
├── data/
│   └── Advertising.csv       # place the downloaded dataset here (not tracked in git)
├── notebooks/
│   └── Bhakti_Task5.ipynb
├── requirements.txt
├── .gitignore
└── README.md
```

## Dataset
This project uses the classic **Advertising dataset** (TV, Radio, Newspaper spend → Sales), widely available on Kaggle - search "advertising sales prediction dataset".

Place the downloaded `Advertising.csv` file inside the `data/` folder before running the notebook.

## Setup
```bash
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage
```bash
jupyter notebook notebooks/Bhakti_Task5.ipynb
```

Run the cells top to bottom. The notebook will:
1. Load the data and run EDA (null check, descriptive stats, pairplot)
2. Plot Sales vs. TV / Radio / Newspaper spend
3. Show a correlation matrix heatmap
4. Split the data into train/test sets
5. Train a baseline Linear Regression model
6. Train an additional Random Forest Regressor
7. Evaluate both models with MAE, RMSE, and R² score
8. Plot residuals for the best-performing model
9. Interpret which advertising channel has the highest impact on Sales

## Results

> **Note:** The table below is from a run against **synthetic placeholder data** (see `data/README.md`), generated with a similar TV/Radio/Newspaper → Sales relationship to the real dataset so the pipeline could be verified end to end. Swap in the real Kaggle `Advertising.csv` and re-run for genuine results before final submission.

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression | 1.3026 | 1.5841 | 0.9004 |
| Random Forest Regressor | 1.6776 | 2.0179 | 0.8384 |

Feature impact on Sales (from the synthetic run): **TV** had the largest effect (coefficient ≈ 0.047, Random Forest importance ≈ 0.64), **Radio** was second (coefficient ≈ 0.191, importance ≈ 0.32), and **Newspaper** contributed the least (coefficient ≈ -0.002, importance ≈ 0.04).

## License
This project is for educational purposes as part of an internship task.
